=== Simple Tooltipfy ===
Contributors: diurno10
Donate link: https://federicocadierno.com
Tags:              block, tooltip, extra information to show, fancy tooltip
Requires at least: 5.4
Tested up to:      5.8.0
Stable tag:        1.3
Requires PHP: 	   7.0
License:           GPLv2 or later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

This plugin allows you to add more or extra information to a paragraph.

== Description ==

This plugin can display anything extra information you need for your copy, also you can choose background color, tooltip direction and tooltip opacity as well.

== Frequently Asked Questions ==

= Does this plugin work with any theme? =

== Installation ==

1. Upload the plugin to the /wp-content/plugins/ directory.
2. Activate the Simple Tooltipfy WordPress plugin through the 'Plugins' menu in WordPress.
3. Add a new block on your page and look for Simple Tooltipfy.

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).
2. This is the second screen shot

== Changelog ==

= 0.1.4 =
* Initial release.

